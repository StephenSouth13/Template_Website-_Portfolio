"use client"

export default function About() {
  return null
}
